<?php
class CZR_menu_button_model_class extends CZR_Model {
  public $defaults = array(
    'data_attributes' => 'data-toggle="collapse" data-target="#primary-nav"',
    'element_tag'     => 'li',
    'element_class'   => ''
  );
}//end class