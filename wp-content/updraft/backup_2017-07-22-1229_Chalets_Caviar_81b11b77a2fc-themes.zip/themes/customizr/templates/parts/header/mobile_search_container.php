<?php
/**
 * The template for displaying the mobile search contaienr
 */
?>
<div class="hidden-lg-up mobile-search__container primary-nav__search">
  <?php get_search_form() ?>
</div>